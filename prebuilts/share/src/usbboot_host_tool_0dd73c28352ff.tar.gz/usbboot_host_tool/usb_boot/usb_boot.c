/** @file usb_boot.c
 *  @brief a daemon program running on PC host, listening on Marvell target
 *  USB dongle board (distinguished by VID/PID))to connect, after connection,
 *  send out dongle image as required by target dongle device.
 *
 *  Copyright (C) 2007-2014, Marvell International Ltd.
 *
 *  This software file (the "File") is distributed by Marvell International
 *  Ltd. under the terms of the GNU General Public License Version 2, June 1991
 *  (the "License").  You may use, redistribute and/or modify this File in
 *  accordance with the terms and conditions of the License, a copy of which
 *  is available along with the File in the gpl.txt file or by writing to
 *  the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307 or on the worldwide web at http://www.gnu.org/licenses/gpl.txt.
 *
 *  THE FILE IS DISTRIBUTED AS-IS, WITHOUT WARRANTY OF ANY KIND, AND THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE
 *  ARE EXPRESSLY DISCLAIMED.  The License provides additional details about
 *  this warranty disclaimer.
 *
 */

#include <errno.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#include <pthread.h>
#include <semaphore.h>
//TODO: read/write/pipe belongs to unistd.h, not for WIN32
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#pragma comment (lib, "Ws2_32.lib")
#include <Psapi.h>
static DWORD processPid;

#else
#include <unistd.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>
#define SOCKET int
#define _CURR_TIME() do{ \
        struct timeval now; \
        gettimeofday(&now, NULL); \
        fprintf(stdout, "%s, line %d: time :%d.%06d\n", \
                        __FUNCTION__, __LINE__, (int)now.tv_sec, (int)now.tv_usec); \
} while (0)
#endif
#include <fcntl.h>

#include <libusb.h>

#ifndef MSG_NOSIGNAL
#define MSG_NOSIGNAL 0
#endif

#ifndef htole32
#define htole32(x) ((uint32_t)(x))
#endif

#define _ERR(fmt, ...) fprintf(stderr, "%s, %d: " fmt,__FUNCTION__, __LINE__, ##__VA_ARGS__)

#define _ENABLE_DEBUG_LOG
#ifdef _ENABLE_DEBUG_LOG
#define _DBG(fmt, ...) printf("%s, %d: " fmt,__FUNCTION__, __LINE__, ##__VA_ARGS__)
#else
#define _DBG(...)
#define _CURR_TIME()
#endif

#define EP_DATA_IN      0x81
#define EP_DATA_OUT     0x01
#define EP_INTR_IN      0x82
#define EP_INTR_OUT     0x02

#define IMG_BUF_SIZE    (1*1024*1024)

#define NAND_IMG_NAME "uNAND.img"
#define EROM_IMAG_NAME "bcm_erom.bin.usb"
#define SYSINIT_IMG_NAME "sysinit.img"
#define BOOTLOADER_IMG_NAME "bootloader.img"
#define DRM_EROM_IMG_NAME "./drm_erom.img"

#define MAX_IMG_PATH_LEN (256-32)
#define MAX_IMG_NAME_LEN 32

static int img_path_prefix_len = 0;
static char img_path_prefix[MAX_IMG_PATH_LEN];
static char img_name[MAX_IMG_PATH_LEN + MAX_IMG_NAME_LEN];

#define MAX_IN_LEN 1024
static unsigned char intr_in_buf[MAX_IN_LEN];

static char * telnet_cmd_s = NULL;

typedef enum{
        IMG_TYPE_eROM = 1,
        IMG_TYPE_SYSINIT = 2,
        IMG_TYPE_BOOTLOADER = 3,
        IMG_TYPE_UNAND = 4,
        IMG_TYPE_DRM_EROM = 5,
        IMG_TYPE_USB_PORT_NUM = 6,
        ABSOLUTE_PATH = 0xFE,
        INVALID_IMG_TYPE = 0xFF,
}IMAGE_REQUEST_TYPE;

typedef enum{
        TYPE_CONSOLE_ARM = 1,
        TYPE_CONSOLE_BCM = 2,
        TYPE_IMG_REQUEST = 0xfaefabcd,
}INTR_EP_MESSAGE_TYPE;

static struct libusb_device_handle *h = NULL;
static uint8_t *imgbuf = NULL;
static struct libusb_transfer *out_transfer = NULL;
static struct libusb_transfer *in_transfer = NULL;
static struct libusb_transfer *intr_out_transfer = NULL;
static struct libusb_transfer *intr_in_transfer = NULL;
static int do_exit = 0;
static uint32_t img_size = 0;
static uint32_t total_data_wrote = 0;
static int request_received = 0;
static int request_not_finished = 0;
static pthread_t poll_thread;
static pthread_cond_t event_cond;
static pthread_mutex_t event_lock;
static FILE *fp = NULL;
static int server_port = 8141;
static pthread_t tcp_server;
static pthread_t server_dongle;
#ifdef _WIN32
static sem_t attach_en;
static sem_t detach_en;
#endif //_WIN32
static sem_t *attach;
static sem_t *detach;
static const char *attach_sem_name = "libusb-attach-semaphore";
static const char *detach_sem_name = "libusb-detach-semaphore";
static SOCKET cli_socket = -1;
static int g_vid = -1;
static int g_pid = -1;
static int g_usb_connected = 0;
static pthread_cond_t client_cond;
static pthread_mutex_t client_lock;
static unsigned char sock_recv_buf[MAX_IN_LEN] = {0};
static libusb_context *ctx = NULL;
static int g_turnoff_telnet = 0;

#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#define pipe(fds) _pipe(fds, 5000, _O_BINARY)
#define snprintf c99_snprintf
inline int c99_vsnprintf(char* str, size_t size, const char* format, va_list ap)
{
        int count = -1;

        if (size != 0)
                count = _vsnprintf_s(str, size, _TRUNCATE, format, ap);
        if (count == -1)
                count = _vscprintf(format, ap);

        return count;
}

inline int c99_snprintf(char* str, size_t size, const char* format, ...)
{
        int count;
        va_list ap;

        va_start(ap, format);
        count = c99_vsnprintf(str, size, format, ap);
        va_end(ap);

        return count;
}
#endif

static int is_img_header_sent = 0;
//static uint32_t IMG_LOAD_ADDR = 0xf0008000;

void my_usleep(int us)
{
#ifdef _WIN32
        Sleep(us/1000);
#else
        usleep(us);
#endif
}
static libusb_device_handle * libusb_open_device_with_vid_pid_subclass(
                libusb_context *ctx, uint16_t vendor_id, uint16_t product_id, uint32_t *sub_class)
{
        struct libusb_device **devs;
        struct libusb_device *found = NULL;
        struct libusb_device *dev;
        struct libusb_device_handle *handle = NULL;
        struct libusb_device_descriptor desc;
        size_t i = 0;
        int r;
        char string[128];

        if (libusb_get_device_list(ctx, &devs) < 0)
                return NULL;

        while ((dev = devs[i++]) != NULL) {
                r = libusb_get_device_descriptor(dev, &desc);
                if (r < 0)
                        goto out;
                _DBG("vid/pid: 0x%04x/0x%04x\n", desc.idVendor, desc.idProduct);
                if (desc.idVendor == vendor_id && desc.idProduct == product_id){
                        *sub_class = desc.bDeviceSubClass;
                        found = dev;
                        _DBG("Serial Number Str Idx: %d\n" , desc.iSerialNumber);
                        break;
                }
        }

        if (found) {
                r = libusb_open(found, &handle);
                if (r < 0)
                        handle = NULL;
        }
        if (handle != NULL && desc.iSerialNumber != 0){
                if (libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber,
                                        (unsigned char*)string, 128) >= 0) {
                        _DBG("serial number: %s\n", string);
                }
        }

out:
        libusb_free_device_list(devs, 1);
        return handle;
}

static int find_boot_target(libusb_context *ctx, const int vid, const int pid, uint32_t *sub_class)
{
        libusb_device *dev;
        uint8_t bus, port;
        uint8_t port_path[8] = {0};
        char buf[16];
        int i, num_ele_in_path = 0;
        h = libusb_open_device_with_vid_pid_subclass(ctx, vid, pid, sub_class);
        if (h != NULL && *sub_class != 0xff){
                dev = libusb_get_device(h);
                bus = libusb_get_bus_number(dev);
                sprintf(buf, "%d-", bus);
                port = libusb_get_port_number(dev);
                _DBG("bus number: %d\n", bus);
                _DBG("port: %d\n", port);
                num_ele_in_path = libusb_get_port_numbers(dev, port_path, sizeof(port_path));
                if (num_ele_in_path > 0) {
                        printf(" path: %d", port_path[0]);
                        sprintf(buf+strlen(buf), "%d", port_path[0]);
                        for (i = 1; i < num_ele_in_path; i++){
                                printf(".%d", port_path[i]);
                                sprintf(buf+strlen(buf), ".%d", port_path[i]);
                        }
                }
                buf[strlen(buf) + 1] = '\0';

                char tmp_file[MAX_IMG_PATH_LEN + MAX_IMG_NAME_LEN];
                strncpy(tmp_file, img_path_prefix, strlen(img_path_prefix)+1);
                strcat(tmp_file, "06_IMAGE");
                _DBG("store USB path to temp file %s.\n", tmp_file);
                FILE *fp = fopen(tmp_file, "wb");
                if (fp == NULL){
                        _ERR("failed to open file %s, err %s\n", tmp_file, strerror(errno));
                        return -EIO;
                }
                fwrite(buf, strlen(buf)+1, 1, fp);
                fclose(fp);
        }

        return h ? 0 : -EIO;
}


static void request_exit(int code)
{
        do_exit = code;
        pthread_cond_signal(&event_cond);
        pthread_cond_signal(&client_cond);
}

#define IMG_REQ_EXIST "i*m*g*r*q*"
static int submit_intr_in_urb(void);
static void process_img_request(uint8_t type, const char *name, int *consumed_len)
{
        switch ( type ){
        case IMG_TYPE_eROM :
                break;
        case IMG_TYPE_SYSINIT :
                strncpy(img_name, img_path_prefix, strlen(img_path_prefix)+1);
                strcat(img_name, SYSINIT_IMG_NAME);
                request_received = 1;
                is_img_header_sent  = 0;
                _DBG("received request from dongle to send image %s.\n", img_name);
                pthread_cond_signal(&event_cond);
                *consumed_len = (strlen(IMG_REQ_EXIST) + 1);
                break;
        case IMG_TYPE_BOOTLOADER :
                strncpy(img_name, img_path_prefix, strlen(img_path_prefix)+1);
                strcat(img_name, BOOTLOADER_IMG_NAME);
                request_received = 1;
                is_img_header_sent  = 0;
                _DBG("received request from dongle to send image %s.\n", img_name);
                pthread_cond_signal(&event_cond);
                *consumed_len = (strlen(IMG_REQ_EXIST) + 1);
                break;
        case IMG_TYPE_DRM_EROM:
                strncpy(img_name, img_path_prefix, strlen(img_path_prefix)+1);
                strcat(img_name, DRM_EROM_IMG_NAME);
                request_received = 1;
                is_img_header_sent  = 0;
                _DBG("received request from dongle to send image %s.\n", img_name);
                pthread_cond_signal(&event_cond);
                *consumed_len = (strlen(IMG_REQ_EXIST) + 1);
                break;
        case ABSOLUTE_PATH:
                strncpy(img_name, name, strlen(name)+1);
                request_received = 1;
                is_img_header_sent  = 0;
                _DBG("received request from dongle to send image %s.\n", img_name);
                pthread_cond_signal(&event_cond);
                *consumed_len = strlen(IMG_REQ_EXIST) + 1 + strlen(name) + 1;
                break;
        case INVALID_IMG_TYPE:
                strncpy(img_name, img_path_prefix, strlen(img_path_prefix)+1);
                strcat(img_name, name);
                request_received = 1;
                is_img_header_sent  = 0;
                _DBG("received request from dongle to send image %s.\n", img_name);
                pthread_cond_signal(&event_cond);
                *consumed_len = strlen(IMG_REQ_EXIST) + 1 + strlen(name) + 1;
                break;
        default :
                strncpy(img_name, img_path_prefix, strlen(img_path_prefix)+1);
                char tmp[4];
                snprintf(tmp, 3, "%02x", type);
                strcat(img_name, tmp);
                strcat(img_name, "_IMAGE");
                request_received = 1;
                is_img_header_sent  = 0;
                _DBG("received request from dongle to send image %s.\n", img_name);
                pthread_cond_signal(&event_cond);
                *consumed_len = (strlen(IMG_REQ_EXIST) + 1);
                break;
        }
}


static uint8_t g_last_img_type;
static uint8_t g_is_img_size_request;
static void process_rcvd_buf(struct libusb_transfer *transfer)
{
        char *s = (char *)transfer->buffer;
        int consumed_len = 0, len = transfer->actual_length;
        char *tmp;

        while (len > 0){
                if ((tmp = strstr(s, IMG_REQ_EXIST)) != NULL){
                        uint8_t type = *(uint8_t *)(tmp + strlen(IMG_REQ_EXIST));
                        g_last_img_type = type;
                        //filter out image request from output string.
                        memmove(tmp, tmp + strlen(IMG_REQ_EXIST) + 1, len - strlen(IMG_REQ_EXIST) - 1);
                        g_is_img_size_request = strncmp(tmp, "07_IMAGE", sizeof("07_IMAGE")) == 0 ? 1 : 0;
                        printf("img_name %s\n", tmp);
                        process_img_request(type, tmp, &consumed_len);
                        transfer->actual_length -= consumed_len;
                }
                s += (strlen(s) + 1);
                len -= (strlen(s) + 1);
        }

        if (cli_socket > 0) {
                send(cli_socket, transfer->buffer, transfer->actual_length, MSG_NOSIGNAL);
        }
        memset(transfer->buffer, 0, transfer->actual_length);
}


static void LIBUSB_CALL cb_intr_in(struct libusb_transfer *transfer)
{
        int ret;
        if (transfer->status != LIBUSB_TRANSFER_COMPLETED) {
                _ERR("img transfer status %d?\n", transfer->status);
                intr_in_transfer = NULL;
                request_exit(2);
                return;
        }

        if (transfer->actual_length > 0){
                _DBG("received len %d\n", transfer->actual_length);
                process_rcvd_buf(transfer);
        }

        if (do_exit)
                return;

        ret = libusb_submit_transfer(intr_in_transfer);
        if (ret < 0) {
                _ERR("libusb_submit_transfer error %d\n", ret);
        }
        return;
}

static int submit_intr_in_urb(void)
{
        int ret = 0;
        libusb_fill_interrupt_transfer(intr_in_transfer, h, EP_INTR_IN,
                        intr_in_buf, sizeof(intr_in_buf), cb_intr_in, NULL, 0);
retry:
        ret = libusb_submit_transfer(intr_in_transfer);
        if (ret == LIBUSB_ERROR_BUSY){
                my_usleep(1000);
                goto retry;
        }

        if (ret < 0){
                _ERR("libusb_submit_transfer err %d\n", ret);
                return ret;
        }
        _DBG("\n");
        return ret;
}

static void LIBUSB_CALL cb_intr_out(struct libusb_transfer *transfer)
{
        if (transfer->status != LIBUSB_TRANSFER_COMPLETED) {
                _ERR("img transfer status %d?\n",transfer->status);
                intr_out_transfer = NULL;
                request_exit(2);
                return;
        }

        _DBG("actual data wrote %d\n", transfer->actual_length);
        return;
}

static int submit_intr_out_urb(uint8_t *out_buf, uint32_t size)
{
        int ret = 0;
        libusb_fill_interrupt_transfer(intr_out_transfer, h, EP_INTR_OUT,
                        out_buf, size, cb_intr_out, NULL, 0);
retry:
        ret = libusb_submit_transfer(intr_out_transfer);
        if (ret == LIBUSB_ERROR_BUSY){
                my_usleep(1000);
                goto retry;
        }

        if (ret < 0){
                _ERR("libusb_submit_transfer err %d\n",ret);
                return ret;
        }
        return ret;
}

static uint32_t get_img_size(void)
{
        uint32_t size = 0;
        fseek(fp, 0L, SEEK_END);
        size = ftell(fp);
        fseek(fp, 0L, SEEK_SET);
        _DBG("size %d\n",size);

        if (g_last_img_type > 0x79 && g_is_img_size_request == 0){
                char tmp_file[MAX_IMG_PATH_LEN + MAX_IMG_NAME_LEN];
                strncpy(tmp_file, img_path_prefix, strlen(img_path_prefix)+1);
                strcat(tmp_file, "07_IMAGE");
                _DBG("store requested image size to temp file %s.\n", tmp_file);

                FILE *fp = fopen(tmp_file, "wb");
                if (fp == NULL){
                        _ERR("failed to open file %s, err %s\n", tmp_file, strerror(errno));
                        return -EIO;
                }
                fwrite(&size, sizeof(uint32_t), 1, fp);
                fclose(fp);
        }
        return size;
}

static uint32_t feed_buf(void)
{
        uint32_t size = 0;
        if (is_img_header_sent == 0){
                *((uint32_t *)imgbuf) = htole32(img_size);
                _DBG("sending image header package, size %d.\n", htole32(img_size));
                return sizeof(uint32_t)*2;
        }

        size = fread(imgbuf, 1, IMG_BUF_SIZE, fp);
        _DBG("read %d bytes from image file.\n", size);

        return size;
}

static void LIBUSB_CALL cb_img_write(struct libusb_transfer *transfer);

static int write_image(const uint32_t size)
{
        int ret = 0;
        out_transfer->length = size;
        libusb_fill_bulk_transfer(out_transfer, h, EP_DATA_OUT, imgbuf,
                        out_transfer->length, cb_img_write, NULL, 0);

retry:
        ret = libusb_submit_transfer(out_transfer);
        if (ret == LIBUSB_ERROR_BUSY){
                my_usleep(1000);
                goto retry;
        }
        if (ret < 0){
                _ERR("libusb_submit_transfer err %d\n", ret);
                return ret;
        }
        return ret;
}

static void send_next_image_block(void)
{
        int ret = 0;
        uint32_t size = feed_buf();
        if (size != 0){
                ret = write_image(size);
                if (ret < 0){
                        _ERR("Error, write iamge failed\n");
                        return;
                }
        }
        return;
}

static void LIBUSB_CALL cb_img_write(struct libusb_transfer *transfer)
{
        if (transfer->status != LIBUSB_TRANSFER_COMPLETED) {
                _ERR("img transfer status %d?\n", transfer->status);
                //out_transfer = NULL;
                request_exit(2);
                return;
        }

        if (is_img_header_sent == 0){
                is_img_header_sent = 1;
        }
        else
                total_data_wrote += transfer->actual_length;
        _DBG("actual data wrote %d, total_data_wrote %d\n",
                        transfer->actual_length, total_data_wrote);

        if (total_data_wrote >= img_size){
                total_data_wrote = 0;
                request_not_finished = 0;
                fclose(fp);
                return;
        }
        else if (!do_exit){
                request_not_finished = 1;
                send_next_image_block();
        }
        return;
}

static int send_first_image_block(char * img_path)
{
        int ret = 0;

        fp = fopen(img_path, "rb");
        if (fp == NULL){
                _ERR("failed to open image file %s, err %s\n",
                                img_path, strerror(errno));
                return -1;
        }

        img_size = get_img_size();
        {
                uint32_t size = feed_buf();
                if (size != 0){
                        ret = write_image(size);
                        if (ret < 0){
                                _ERR("Error, write iamge failed\n");
                        }
                }
        }

        return ret;
}

static void destroy_sem(void)
{
#ifdef _WIN32
        sem_destroy(detach);
        sem_destroy(attach);
#else //_WIN32
	sem_unlink(detach_sem_name);
	sem_unlink(attach_sem_name);
#endif //_WIN32
}

static void sighandler(int signum)
{
        request_exit(1);
        sem_post(attach);
        sem_post(detach);
#ifndef _WIN32
        pthread_kill(tcp_server, SIGALRM);
#endif
		destroy_sem();
        //pthread_kill(poll_thread, SIGALRM); //not needed, since this thread will
        //not block for ever.
}


static void *poll_thread_main(void *arg)
{
        int r = 0;
        _DBG("poll thread running\n");

        while (!do_exit) {
                struct timeval tv = { 1, 0 };
                r = libusb_handle_events_timeout(ctx, &tv);
                if (r < 0) {
                        request_exit(2);
                        break;
                }
        }

        _DBG("poll thread shutting down\n");
        return NULL;
}

static SOCKET create_listen_socket(int port)
{
        SOCKET s;
#ifdef _WIN32
        WSADATA wsaData;
        int iResult;
        struct sockaddr_in service;

        //int iSendResult;

        // Initialize Winsock
        iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
        if (iResult != 0) {
                _ERR("WSAStartup failed with error: %d\n", iResult);
                return -1;
        }


        // Create a SOCKET for connecting to server
        s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (s == INVALID_SOCKET) {
                _ERR("socket failed with error: %ld\n", WSAGetLastError());
                WSACleanup();
                return -1;
        }

        // Setup the TCP listening socket
        memset(&service, 0, sizeof(struct sockaddr_in));
        service.sin_family = AF_INET;
        service.sin_addr.s_addr = INADDR_ANY;
        service.sin_port = htons(port);
        iResult = bind(s, (SOCKADDR *)&service, sizeof (service));
        if (iResult == SOCKET_ERROR) {
                _ERR("bind failed with error: %d\n", WSAGetLastError());
                closesocket(s);
                WSACleanup();
                return 1;
        }

        iResult = listen(s, SOMAXCONN);
        if (iResult == SOCKET_ERROR) {
                _ERR("listen failed with error: %d\n", WSAGetLastError());
                closesocket(s);
                WSACleanup();
                return -1;
        }
#else
        struct sockaddr_in name;

        s = socket(AF_INET, SOCK_STREAM, 0);
        if (s < 0) {
                _ERR("create socket err %s\n", strerror(errno));
                return -1;
        }

        int optval = 1;
        setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval);

        name.sin_family = AF_INET;
        name.sin_addr.s_addr = INADDR_ANY;
        name.sin_port = htons(port);
        if(bind(s, (void*) &name, sizeof(name))) {
                _ERR("binding tcp socket %d, err %s\n", port, strerror(errno));
                return -1;
        }
        if(listen(s, 1) == -1) {
                _ERR("listen tcp socket %d, err %s\n", port, strerror(errno));
                return -1;
        }
#endif
        return s;

}

#include "telnet.h"
static int send_telnet_cmd(SOCKET cli_socket, int cmd, int opt)
{
        unsigned char buf[3];
        unsigned char *p = buf;

        _DBG("sending %d, opt %d\n", cmd, opt);

        *p++ = IAC;
        if (!TELCMD_OK(cmd)) {
                return(-1);
        }
        *p++ = cmd;
        if ((cmd == DONT) || (cmd == DO) || (cmd == WONT) || (cmd == WILL)) {
                *p++ = opt;
        }

        if (send(cli_socket, buf, p - buf, 0) <= 0)
                return(-1);

        return(0);
}

static void init_telnet_conn(SOCKET cli_socket)
{
        send_telnet_cmd(cli_socket, DO, TELOPT_BINARY);
        send_telnet_cmd(cli_socket, WONT, TELOPT_ECHO);
        send_telnet_cmd(cli_socket, DO, TELOPT_SGA);
        send_telnet_cmd(cli_socket, WILL, TELOPT_BINARY);
        send_telnet_cmd(cli_socket, WILL, TELOPT_SGA);
}

static int process_recved_telnet_cmd(SOCKET cli_socket, unsigned char c)
{
        int i, ret;
        unsigned char buf[3];
        char recv_buf[1];
        switch (c) {
        case AYT:
                send_telnet_cmd(cli_socket, NOP, 0);
                break;
        case WILL:
        case DO:
                ret = recv(cli_socket, recv_buf, 1, 0);//receive command option.
                if (ret <= 0){
                        _ERR("recv failed, err %s\n", strerror(errno));
                        return -1;
                }

                _DBG("recved cmd %d, opt %d\n", c, recv_buf[0]);
                send_telnet_cmd(cli_socket, c + 1, TELOPT_ECHO);//reject client command.
                break;
        case DONT:
        case WONT:
                ret = recv(cli_socket, recv_buf, 1, 0);//receive command option.
                if (ret <= 0){
                        _ERR("recv failed, err %s\n", strerror(errno));
                        return -1;
                }

                _DBG("recved cmd %d, opt %d\n", c, recv_buf[0]);
                send_telnet_cmd(cli_socket, c, recv_buf[0]);
                break;
        case SB:
                for (i = 0; i < 128; i++){
                        ret = recv(cli_socket, recv_buf, 1, 0);
                        if (ret <= 0){
                                _ERR("recv failed, err %s\n", strerror(errno));
                                return -1;
                        }

                        _DBG("recved %d, char %c\n", recv_buf[0], recv_buf[0]);
                        if (buf[0] == IAC) {
                                ret = recv(cli_socket, recv_buf, 1, 0);
                                if (ret <= 0){
                                        _ERR("recv failed, err %s\n", strerror(errno));
                                        return -1;
                                }

                                _DBG("recved %d, char %c\n", recv_buf[0], recv_buf[0]);
                                break;
                        }
                }
                break;
        }
        return 0;
}

static int telnet_getchar(SOCKET cli_socket, unsigned char *c)
{
        unsigned char recv_buf[1];
        int ret;
        while (1){
                ret = recv(cli_socket, recv_buf, 1, 0);
                if (ret <= 0){
                        _ERR("recv failed, err %s\n", strerror(errno));
                        return -1;
                }

                _DBG("recved %d, char %c\n", recv_buf[0], recv_buf[0]);

                if (recv_buf[0] == '\r' || recv_buf[0] == '\0' || recv_buf[0] == '\n') {
                        *c = '\n';
                        return 0;
                }

                if (recv_buf[0] == IAC) {
                        ret = recv(cli_socket, recv_buf, 1, 0);
                        if (ret <= 0){
                                _ERR("recv failed, err %s\n", strerror(errno));
                                return -1;
                        }

                        _DBG("recved %d, char %c\n", recv_buf[0], recv_buf[0]);
                        if (recv_buf[0]!= IAC) {
                                ret = process_recved_telnet_cmd(cli_socket, recv_buf[0]);
                                if (ret < 0){
                                        return -1;
                                }
                        }
                }
                else
                        break;
        }

        *c = recv_buf[0];
        return 0;
}

static void  filter_out_substring(char *str, int * len, const char * sub_str)
{
        char *s = str;
        char *p;
        while((s = strstr(s, sub_str)) != NULL){
                p = s + strlen(sub_str);
                memmove(s, p, (strlen(p) + 1));
                *len -= strlen(sub_str);
        }
}

static void * tcp_server_func(void *args)
{
        int port = *(int *)args;
        SOCKET s;

        s = create_listen_socket(port);;
        if (s < 0) {
                _ERR("create socket");
                return NULL;
        }

        while(!do_exit) {

next_client:
                _DBG("server listening on port %d\n", port);
                cli_socket = accept(s, NULL, NULL);
                if(cli_socket < 0){
                        _ERR("accept tcp socket %d, err %s\n", port, strerror(errno));
                        return NULL;
                }
                _DBG("client connected.\n");
                pthread_cond_signal(&client_cond);
                init_telnet_conn(cli_socket);
                while(do_exit != 1) {
                        int ret = 0, i = 0;
                        unsigned char c;
                        do {
                                ret = telnet_getchar(cli_socket, &c);
                                if(ret < 0) {
                                        _ERR("client disconnected.\n");
                                        goto next_client;
                                }
                                sock_recv_buf[i++] = c;
                        }while (c != '\n' && i < MAX_IN_LEN);

                        if (g_usb_connected && i > 0){
                                _DBG("sending %s, len %d to dongle.\n", sock_recv_buf, i);
                                //FIXME: filter out unwanted PuTTY from input
                                //string.
                                filter_out_substring((char *)sock_recv_buf, &i, "PuTTY");
                                //FIXME: need mutex to protect
                                //submit_intr_out_urbsubmit again before cb_intr_out.
                                ret = submit_intr_out_urb(sock_recv_buf, i);
                                if(ret != 0) {
                                        _ERR("send to dongle device failed.\n");
                                        request_exit(2);
                                }
                        }
                }
#ifdef _WIN32
                shutdown(cli_socket, SD_SEND);
                closesocket(cli_socket);
#else
                close(cli_socket);
#endif
                cli_socket = -1;
        }
#ifdef _WIN32
        closesocket(s);
#else
        close(s);
#endif
        return NULL;
}

static int allocate_transfer(void)
{
        out_transfer = libusb_alloc_transfer(0);
        if (!out_transfer){
                _ERR("libusb_alloc_transfer error\n");
                return -1;
        }
        intr_in_transfer = libusb_alloc_transfer(0);
        if (!intr_in_transfer){
                _ERR("libusb_alloc_transfer error\n");
                goto out_free;
        }

        intr_out_transfer = libusb_alloc_transfer(0);
        if (!intr_out_transfer){
                _ERR("libusb_alloc_transfer error\n");
                goto intr_in_free;
        }

        libusb_fill_bulk_transfer(out_transfer, h, EP_DATA_OUT, imgbuf,
                        sizeof(imgbuf), cb_img_write, NULL, 0);
        libusb_fill_interrupt_transfer(intr_in_transfer, h, EP_INTR_IN,
                        intr_in_buf, sizeof(intr_in_buf), cb_intr_in, NULL, 0);
        libusb_fill_interrupt_transfer(intr_out_transfer, h, EP_INTR_OUT,
                        sock_recv_buf, sizeof(sock_recv_buf), cb_intr_out, NULL, 0);

        return 0;

intr_in_free:
        libusb_free_transfer(intr_in_transfer);
        intr_in_transfer = NULL;
out_free:
        libusb_free_transfer(out_transfer);
        out_transfer = NULL;
        return -1;
}


static void release_transfer(void)
{
        if(in_transfer) { libusb_free_transfer(in_transfer); in_transfer = NULL; }
        if(out_transfer) { libusb_free_transfer(out_transfer); out_transfer = NULL; }
        if(intr_in_transfer) { libusb_free_transfer(intr_in_transfer); intr_in_transfer = NULL; }
        if(intr_out_transfer) { libusb_free_transfer(intr_out_transfer); intr_out_transfer = NULL; }
}


static int submit_first_urbs(void)
{
        int ret = submit_intr_in_urb();
        if (ret < 0) {
                _ERR("libusb_submit_transfer error %d\n", ret);
        }

        return ret;
}

static int serve_irom_stage_dongle(void)
{
        int ret = 0;
        ret = libusb_detach_kernel_driver(h, 0);
        if (ret < 0) {
                _ERR("libusb_detach_kernel_driver error %d, ignore it\n", ret);
        }

        ret = libusb_claim_interface(h, 0);
        if (ret < 0) {
                _ERR("usb_claim_interface error %d\n", ret);
                goto out;
        }
        _DBG("claimed interface\n");

        out_transfer = libusb_alloc_transfer(0);
        if (!out_transfer){
                _ERR("libusb_alloc_transfer error\n");
                goto out_free_interface;
        }

        is_img_header_sent = 1;
        request_not_finished = 1;
        strncpy(img_name, img_path_prefix, strlen(img_path_prefix)+1);
        strcat(img_name, EROM_IMAG_NAME);
        ret = send_first_image_block(img_name);
        if (ret < 0){
                _ERR("Error, write image failed\n");
                goto out_free;
        }

        while (!do_exit && request_not_finished) {
                struct timeval tv = { 1, 0 };
                ret = libusb_handle_events_timeout(ctx, &tv);
                if (ret < 0) {
                        request_exit(2);
                        break;
                }
                _DBG("request_not_finished %d\n", request_not_finished);
        }
        is_img_header_sent = 0;

        if (out_transfer) {
                ret = libusb_cancel_transfer(out_transfer);
                if (ret < 0){
                        request_exit(2);
                }
        }

out_free:
        libusb_free_transfer(out_transfer);
        out_transfer = NULL;
out_free_interface:
        _DBG("libusb_release_interface\n");
        libusb_release_interface(h, 0);
out:
        _DBG("libusb_close -- %p\n", h);
        libusb_close(h);
        h = NULL;

        return 0;
}


static int serve_one_target(void)
{
        int ret = 0;

        uint32_t sub_class = 0;

        do_exit = 0;

        _DBG("libusb_init\n");

        ret = libusb_init(&ctx);
        if (ret < 0) {
                _ERR("failed to initialise libusb\n");
                exit(1);
        }

        _DBG("libusb_open_device_with_vid_pid_subclass\n");
        ret = find_boot_target(ctx, g_vid, g_pid, &sub_class);
        if (ret < 0) {
                _ERR("Could not find/open device %x %x\n", g_vid, g_pid);
                goto exit_1;
        }

        _DBG("sub_class: %d\n", sub_class);
        if (sub_class == 0xff){
                _DBG("iROM stage dongle connected.\n");
                ret = serve_irom_stage_dongle();
                goto exit_1;
        }

        ret = libusb_detach_kernel_driver(h, 0);
        if (ret < 0) {
                _ERR("libusb_detach_kernel_driver error %d, ignore it\n", ret);
        }

        _DBG("claimed interface\n");
        ret = libusb_claim_interface(h, 0);
        if (ret < 0) {
                _ERR("usb_claim_interface error %d\n", ret);
                goto out;
        }

        _DBG("pthread_create poll_thread_main\n");
        ret = pthread_create(&poll_thread, NULL, poll_thread_main, NULL);
        if (ret) {
                goto out_release;
        }

        _DBG("allocate_transfer\n");
        ret = allocate_transfer();
        if (ret < 0){
                request_exit(2);
                pthread_join(poll_thread, NULL);
                goto out_release;
        }

        _DBG("submit_first_urbs\n");
        ret = submit_first_urbs();
        if (ret < 0){
                request_exit(2);
                goto out_join_thread;
        }

        g_usb_connected = 1;

        while (!do_exit) {
                pthread_mutex_lock(&event_lock);
                pthread_cond_wait(&event_cond, &event_lock);
                pthread_mutex_unlock(&event_lock);

                if (request_received && !request_not_finished){
                        _DBG("start processing image %s request.\n", img_name);
                        ret = send_first_image_block(img_name);
                        if (ret < 0){
                                _ERR("Error, write image failed\n");
                                break;
                        }
                        request_received = 0;
                }
        }

        g_usb_connected = 0;

        //shut_down();

out_join_thread:
        pthread_join(poll_thread, NULL);

out_release:
        libusb_release_interface(h, 0);
out:
        libusb_close(h);
        h = NULL;

        release_transfer();
exit_1:
        libusb_exit(ctx);
        ctx = NULL;

        return ret;
}

static void *service_thread_func(void *args)
{
        while(do_exit != 1){
                sem_wait(attach);
                if (do_exit == 1)
                        break;
                serve_one_target();
                sem_wait(detach);
        }
        return NULL;
}

#ifdef _WIN32
#include <libusbhp.h>
static void attach_fn(struct libusbhp_device_t *device, void *user_data)
{
        _DBG("attach\n");
        if(device)
                _DBG(" -- (%04x/%04x)\n", device->idVendor, device->idProduct);
        my_usleep(1000000);//wait usb device stable before accessing it.
        if (device->idVendor == g_vid && device->idProduct == g_pid){
                sem_post(attach);
        }
}

static void detach_fn(struct libusbhp_device_t *device, void *user_data)
{
        _DBG("detach\n");
        if(device)
                _DBG(" -- (%04x/%04x)\n", device->idVendor, device->idProduct);
        if (device->idVendor == g_vid && device->idProduct == g_pid){
                sem_post(detach);
        }
}

#else //_WIN32

static int LIBUSB_CALL attach_cb(libusb_context *ctx, libusb_device *dev, libusb_hotplug_event event, void *user_data)
{
	struct libusb_device_descriptor desc;

	_DBG("attach\n");
	int ret = libusb_get_device_descriptor(dev, &desc);
	if (ret < 0) {
		_ERR("device not found in libsub.\n");
		return 1;
	}
	_DBG("vid/pid: 0x%04x/0x%04x\n", desc.idVendor, desc.idProduct);

	my_usleep(1000000);//wait usb device stable before accessing it.
	if (desc.idVendor == g_vid && desc.idProduct == g_pid){
		sem_post(attach);
	}
	return 0;
}

static int LIBUSB_CALL detach_cb(libusb_context *ctx, libusb_device *dev, libusb_hotplug_event event, void *user_data)
{
	struct libusb_device_descriptor desc;

	_DBG("detach\n");
	int ret = libusb_get_device_descriptor(dev, &desc);
	if (ret < 0) {
		_ERR("device not found in libsub.\n");
		return 1;
	}
	_DBG("vid/pid: 0x%04x/0x%04x\n", desc.idVendor, desc.idProduct);

        if (desc.idVendor == g_vid && desc.idProduct == g_pid){
                sem_post(detach);
        }
	return 0;
}


#endif

void cmd_background(char * cmd_s) {
        if (cmd_s) {
                int cmd_s_len = strlen(cmd_s);
                char * cmd_buf = (char *)malloc(cmd_s_len + 16);
                if (cmd_buf) {
#ifdef _WIN32
                        memcpy(cmd_buf, "start ", 6);
                        memcpy(cmd_buf + 6, cmd_s, cmd_s_len + 1);
#else /* LINUX */
                        memcpy(cmd_buf, cmd_s, cmd_s_len);
                        memcpy(cmd_buf + cmd_s_len, "&", 2);
#endif
                        system(cmd_buf);
                        free(cmd_buf);
                }
        }
}

static int create_sem(void)
{
#ifdef _WIN32
        sem_init(&attach_en, 0, 0);
        sem_init(&detach_en, 0, 0);
        attach = &attach_en;
        detach = &detach_en;
#else //_WIN32
	int ret = sem_unlink(attach_sem_name);
	if (ret) {
		perror("sem_unlink");
	}
	attach = sem_open(attach_sem_name, O_CREAT, O_RDWR, 0);
	if (attach == SEM_FAILED) {
		perror("sem_open");
                return -1;
	}

	ret = sem_unlink(detach_sem_name);
	if (ret) {
		perror("sem_unlink");
	}
	detach = sem_open(detach_sem_name, O_CREAT, O_RDWR, 0);
	if (detach == SEM_FAILED) {
		perror("sem_open");
	        sem_unlink(attach_sem_name);
                return -1;
	}
#endif //_WIN32

        return 0;
}


static void polling_for_hotplug_event(void)
{
#ifdef _WIN32
        struct libusbhp_t *handle;
        int ret = libusbhp_init(&handle);
        if(ret != 0) {
                _ERR("Could not initialise handle.\n");
                return;
        }

        libusbhp_register_hotplug_listeners(handle, attach_fn, detach_fn, NULL);
        struct timeval tv;
        tv.tv_sec = 1;
        tv.tv_usec = 0;
        do {
                ret = libusbhp_handle_events_timeout(handle, &tv);
                if (ret){
                        _ERR("handle_events failed [%d]...\n", ret);
                        break;
                }
        } while (1);

        _DBG("libusbhp_exit\n");
        libusbhp_exit(handle);
#else //_WIN32

        libusb_context *ctx_hp = NULL;
        libusb_hotplug_callback_handle hp[2];

        _DBG("libusb_init\n");
        int ret = libusb_init(&ctx_hp);
        if (ret < 0) {
                _ERR("failed to initialise libusb\n");
                return;
        }

	if (!libusb_has_capability (LIBUSB_CAP_HAS_HOTPLUG)) {
		_ERR("Hotplug capabilites are not supported on this platform\n");
                return;
	}

	ret = libusb_hotplug_register_callback (ctx_hp, LIBUSB_HOTPLUG_EVENT_DEVICE_ARRIVED, 0, LIBUSB_HOTPLUG_MATCH_ANY,
		LIBUSB_HOTPLUG_MATCH_ANY, LIBUSB_HOTPLUG_MATCH_ANY, attach_cb, NULL, &hp[0]);
	if (LIBUSB_SUCCESS != ret) {
		_ERR("Error registering callback 0\n");
                return;
	}

	ret = libusb_hotplug_register_callback (ctx_hp, LIBUSB_HOTPLUG_EVENT_DEVICE_LEFT, 0, LIBUSB_HOTPLUG_MATCH_ANY, LIBUSB_HOTPLUG_MATCH_ANY, LIBUSB_HOTPLUG_MATCH_ANY, detach_cb, NULL, &hp[1]);
	if (LIBUSB_SUCCESS != ret) {
		_ERR("Error registering callback 1\n");
                return;
	}

        while (do_exit != 1) {
                struct timeval tv = { 1, 0 };
                ret = libusb_handle_events_timeout(ctx_hp, &tv);
                if (ret < 0) {
                        break;
                }
        }

        _DBG("event handling finished do_exit = %d\n", do_exit);
        libusb_exit(ctx_hp);
        ctx_hp = NULL;
#endif //_WIN32

}


int main(int argc, char **argv)
{
        int ret = 0;

        if (argc < 5) {
                _ERR("Usage:%s [Vendor ID] [Product ID] [IMAGE_DIR] [TELENT_PORT] [TELENT CLIENT CMD]\n", argv[0]);

                g_vid = 0x1286;
                g_pid = 0x8174;

                img_path_prefix_len = 2;
                memcpy(img_path_prefix, "./", 3);

                server_port = 8141;
        }else{
                g_vid = strtol(argv[1], NULL, 16);
                g_pid = strtol(argv[2], NULL, 16);
                _DBG("verder_id/product_id: 0x%04x/%04x\n", g_vid, g_pid);

                img_path_prefix_len = strlen(argv[3]);
                if (img_path_prefix_len + 1 > sizeof(img_path_prefix) + MAX_IMG_NAME_LEN) {
                        _ERR("image path name too long\n");
                        exit(0);
                }
                memcpy(img_path_prefix, argv[3], img_path_prefix_len + 1);

                server_port = atoi(argv[4]);
        }

        if (argc == 6) {
                telnet_cmd_s = argv[5];
                /*turn off telnet client function completely.*/
                if (strncmp(argv[5], "turn_off_telnet", sizeof("turn_off_telnet")) == 0) {
                        _DBG("user requires to turn off telnet server function.\n");
                        g_turnoff_telnet = 1;
                }
        }

#ifdef WIN32
        signal(SIGINT, sighandler);
        signal(SIGTERM, sighandler);
#else
        struct sigaction sigact;
        sigact.sa_handler = sighandler;
        sigemptyset(&sigact.sa_mask);
        sigact.sa_flags = 0;
        sigaction(SIGINT, &sigact, NULL);
        sigaction(SIGTERM, &sigact, NULL);
        sigaction(SIGQUIT, &sigact, NULL);
#endif

        pthread_cond_init(&event_cond, NULL);
        pthread_mutex_init(&event_lock, NULL);
        pthread_cond_init(&client_cond, NULL);
        pthread_mutex_init(&client_lock, NULL);

        imgbuf = (uint8_t *)malloc(IMG_BUF_SIZE + 4);
        if (imgbuf == NULL){
                _ERR("failed to malloc, err %s\n", strerror(errno));
                exit(1);
        }

        ret = create_sem();
        if (ret != 0) {
                exit(1);
        }

        if (g_turnoff_telnet == 0) {
                // TCP server/client
                ret = pthread_create(&tcp_server, NULL, tcp_server_func, &server_port);
                if (ret < 0) {
                        _ERR("pthread_create err, %s\n", strerror(errno));
                        goto exit_1;
                }

                _DBG("wait for connection on port: %d\n", server_port);

                cmd_background(telnet_cmd_s);
                _DBG("telnet client started\n");

                pthread_mutex_lock(&client_lock);
                pthread_cond_wait(&client_cond, &client_lock);
                pthread_mutex_unlock(&client_lock);
        }


        ret = pthread_create(&server_dongle, NULL, service_thread_func, NULL);
        if (ret < 0) {
                _ERR("pthread_create err, %s\n", strerror(errno));
		goto exit_2;
        }


        polling_for_hotplug_event();

        pthread_join(server_dongle, NULL);
exit_2:
        pthread_join(tcp_server, NULL);
exit_1:
        destroy_sem();
        free(imgbuf);
        return 0;
}
